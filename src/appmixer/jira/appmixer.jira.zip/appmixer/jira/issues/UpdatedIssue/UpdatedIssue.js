'use strict';
//const moment = require('moment');
const { parse, format } = require('date-fns');
const commons = require('../../jira-commons');

function processIssues(knownIssues, actualIssues, newIssues, issue) {
    const uniqueString = `${issue['id']}${issue['updated']}`;
    if (knownIssues && !knownIssues.has(uniqueString)) {
        newIssues.add(issue);
    }
    actualIssues.add(uniqueString);
}

let currentDateWithTZ;

/**
 * Component which triggers whenever an issue is updated.
 * @extends {Component}
 */
module.exports = {

    async start(context) {
        const { profileInfo: { apiUrl }, auth } = context;
        const now = new Date();

        const myself = await commons.getAPI({
            endpoint: `${apiUrl}myself`,
            credentials: auth
        });

        context.log({ stage: 'myself', myself });

        const currentDateFormatter = new Intl.DateTimeFormat('en-GB', { timeZone: myself.timeZone, timeStyle: 'short', dateStyle: 'short' });

        currentDateWithTZ = currentDateFormatter.format(now);

        context.log({ stage: 'currentDateWithTZ', currentDateWithTZ });
    },

    async tick(context) {

        const { profileInfo: { apiUrl }, auth } = context;
        const { project } = context.properties;

        const state = await context.loadState();

        // let { updatedTime } = await context.loadState();
        // const current = moment().utc().format('YYYY-MM-DD HH:mm');

        // if (!updatedTime) {
        //     updatedTime = current;
        // }
        const parsedDate = parse(currentDateWithTZ, 'dd/MM/yyyy, HH:mm', new Date());
        const formattedDate = format(parsedDate, 'yyyy-MM-dd HH:mm');

        context.log({ stage: 'formattedDate', formattedDate });

        const params = {
            maxResults: 1000,
            jql: `updated >= "${formattedDate}"`
        };

        if (project) {
            params.jql += ` AND project = "${project}"`;
        }

        params.jql += ' ORDER BY updated';

        const issues = await commons.searchIssuesNoPagination({
            endpoint: `${apiUrl}search`,
            credentials: auth,
            key: 'issues',
            params
        });
        context.log({ stage: 'searchIssueResponse', issues });

        let known = Array.isArray(state.known) ? new Set(state.known) : null;
        let actual = new Set();
        let diff = new Set();

        issues.forEach(processIssues.bind(null, known, actual, diff));
        // const latestUpdatedInUnixTime = issues[0].updated;
        // const latestCreatedInUnixTime = issues[0].created;
        //const latestUpdatedInUnixTime = new Date(issues[0].updated).valueOf();
        //const latestCreatedInUnixTime = new Date(issues[0].created).valueOf();

        // context.log({ stage: 'latestUpdatedInUnixTime', latestUpdatedInUnixTime });
        // context.log({ stage: 'latestCreatedInUnixTime', latestCreatedInUnixTime });

        if (diff.size) {
            //const promises = [];
            const issuesArr = Array.from(diff).reverse();
            const filteredNewIssues = issuesArr.filter(i => latestUpdatedInUnixTime >= latestCreatedInUnixTime);
            context.log({ stage: 'filteredNewIssues', filteredNewIssues });
            for (const issue of filteredNewIssues) {
                await context.sendJson(issue, 'issue');
            }
            // issues.forEach(issue => {
            //     context.log({ stage: 'issueID', issue: issue.key });
            //     promises.push(context.sendJson(issue, 'issue'));
            // });
            // await Promise.all(promises);
        }

        return context.saveState({ updatedTime: current });
    }
};
