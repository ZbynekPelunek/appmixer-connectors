'use strict';
//const moment = require('moment');
const commons = require('../../jira-commons');

/**
 * Process issues to find newly created.
 * @param {Set} knownIssues
 * @param {Set} actualIssues
 * @param {Set} newIssues
 * @param {Object} issue
 */
function processIssues(knownIssues, actualIssues, newIssues, issue) {

    if (knownIssues && !knownIssues.has(issue['id'])) {
        newIssues.add(issue);
    }
    actualIssues.add(issue['id']);
}

/**
 * Component which triggers whenever new issue is created.
 * @extends {Component}
 */
module.exports = {

    async tick(context) {

        const { profileInfo: { apiUrl }, auth } = context;
        const { project } = context.properties;

        //let { createdTime } = await context.loadState();
        const state = await context.loadState();
        //const current = moment().utc().format('YYYY-MM-DD HH:mm');

        // if (!createdTime) {
        //     createdTime = current;
        // }

        //context.log({ stage: 'current', current });
        const params = {
            maxResults: 1000,
            jql: 'created > "-1w"'
        };

        if (project) {
            params.jql += ` AND project = "${project}"`;
        }

        params.jql += ' ORDER BY created';

        //context.log({ stage: 'auth', auth });
        const issues = await commons.searchIssuesNoPagination({
            endpoint: `${apiUrl}search`,
            credentials: auth,
            key: 'issues',
            params
        });
        context.log({ stage: 'searchIssueResponse', issues });

        // if (Array.isArray(issues) && issues.length > 0) {
        //     const promises = [];
        //     issues.forEach(issue => {
        //         context.log({ stage: 'issueID', issue: issue.key });
        //         promises.push(context.sendJson(issue, 'issue'));
        //     });
        //     await Promise.all(promises);
        // }

        let known = Array.isArray(state.known) ? new Set(state.known) : null;
        let actual = new Set();
        let diff = new Set();

        issues.forEach(processIssues.bind(null, known, actual, diff));

        if (diff.size) {
            //const promises = [];
            const issuesArr = Array.from(diff).reverse();
            for (const issue of issuesArr) {
                await context.sendJson(issue, 'issue');
            }
            // issues.forEach(issue => {
            //     context.log({ stage: 'issueID', issue: issue.key });
            //     promises.push(context.sendJson(issue, 'issue'));
            // });
            // await Promise.all(promises);
        }

        return context.saveState({ known: Array.from(actual) });
    }
};
